<?php
/*
 * Plugin Name: costing calculator 
 * Description: A costing calculator 
 * Author: Matthew 
 * Version: 1.0
 */

  
function add_my_css_and_my_js_files(){
    wp_enqueue_script('main-amchart', plugins_url('amcharts/amcharts.js', __FILE__ ) ); // NOT a new line
	wp_enqueue_script('serial-amchart', plugins_url('amcharts/serial.js', __FILE__ ) ); 	
}
add_action('wp_enqueue_scripts', "add_my_css_and_my_js_files"); 



function include_jQuery() {
    if (!is_admin()) {
        wp_enqueue_script('jquery');
    }
}
add_action('init', 'include_jQuery');


add_action( 'init', 'register_shortcodes' );
function register_shortcodes() {
	add_shortcode( 'displaycalcs', 'mp_calcs_display' );
}

function mp_calcs_display() {
return ' 
	
	
	  <div id="chartdiv" style="width: 640px; height: 400px;"></div>
 



<script type="text/javascript">
    	


var chartData = [{
		"country": "USA",
		"visits": 4252
	}, {
		"country": "China",
		"visits": 1882
	}, {
		"country": "Japan",
		"visits": 1809
	}, {
		"country": "Germany",
		"visits": 1322
	}, {
		"country": "UK",
		"visits": 1122
	}, {
		"country": "France",
		"visits": 1114
	}, {
		"country": "India",
		"visits": 984
	}, {
		"country": "Spain",
		"visits": 711
	}, {
		"country": "Netherlands",
		"visits": 665
	}, {
		"country": "Russia",
		"visits": 580
	}, {
		"country": "South Korea",
		"visits": 443
	}, {
		"country": "Canada",
		"visits": 441
	}, {
		"country": "Brazil",
		"visits": 395
	}, {
		"country": "Italy",
		"visits": 386
	}, {
		"country": "Australia",
		"visits": 384
	}, {
		"country": "Taiwan",
		"visits": 338
	}, {
		"country": "Poland",
		"visits": 328
	}];

AmCharts.ready(function() {

var chart = new AmCharts.AmSerialChart();
chart.dataProvider = chartData;
chart.categoryField = "country";
var graph = new AmCharts.AmGraph();
graph.valueField = "visits";
graph.type = "column";
chart.addGraph(graph);


chart.write('chartdiv');


});
	
 
 
	
	
	
	
			
	

	 
	</script> ';

} 